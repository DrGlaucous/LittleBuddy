#! /bin/bash

git submodule update --init --recursive