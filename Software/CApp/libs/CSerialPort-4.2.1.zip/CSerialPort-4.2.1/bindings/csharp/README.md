# CSerialPort for CSharp

```
swig: 4.1.0
cmake: 3.8.2
```

## Build

```
mkdir bin
cd bin
cmake .. 
cmake --build .
```

## Run

```
cd bin
CommCSharp
```

