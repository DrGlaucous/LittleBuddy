Scripts And Configuration For Building
=========

* `packr-config-mac.json` is the configuration for [packr](https://github.com/libgdx/packr) to deliver a Mac OS Application.
* `lanch4jConfig.xml` is the configuration for [lanch4j](http://launch4j.sourceforge.net/) to deliver `.exe` for Windows.
