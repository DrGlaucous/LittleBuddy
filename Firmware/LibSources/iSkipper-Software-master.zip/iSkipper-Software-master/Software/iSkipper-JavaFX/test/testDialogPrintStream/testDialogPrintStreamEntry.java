package testDialogPrintStream;

public class testDialogPrintStreamEntry
{
	public static void main(String[] args)
	{
		testDialogPrintStreamMain.main(args);
	}
}
