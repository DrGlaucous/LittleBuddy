package testConfigurationPane;

public final class EntryConfigurationPane
{

	public static void main(String[] args)
	{
		ShowConfigurationPane.main(args);

	}

}
