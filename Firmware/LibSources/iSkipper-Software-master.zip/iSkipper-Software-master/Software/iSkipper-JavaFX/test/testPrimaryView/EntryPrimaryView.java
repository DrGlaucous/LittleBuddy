package testPrimaryView;

public class EntryPrimaryView
{

	public static void main(String[] args)
	{
		ShowPrimaryView.main(args);
	}
}
