package testMultipleChoicePane;
public class EntryMultipleChoicePane
{
	public static void main(String[] args)
	{
		ShowMultipleChoicePane.main(args);
	}
}
