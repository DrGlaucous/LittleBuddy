package application;

/**
 * The REAL entry point of the program. Just for JavaFX11's Incompatibility:(
 *
 */
public class EntryPoint
{

	public static void main(String[] args)
	{
		Main.main(args);
	}

}
